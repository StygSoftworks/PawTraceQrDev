import { useEffect } from "react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";

import { useAuth } from "@/auth/AuthProvider"; // or "@/hooks/useAuth" if that's your path
import { useProfile } from "@/profile/useProfile"; // the React Query hook we outlined earlier

import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertDescription } from "@/components/ui/alert";

const ProfileSchema = z.object({
  display_name: z.string().min(1, "Please enter your name").max(80),
  avatar_url: z.string().url("Must be a valid URL").or(z.literal("")).optional(),
  phone: z.string().max(15, "Must be at most 15 characters").optional(),
});

type ProfileForm = z.infer<typeof ProfileSchema>;

const PasswordSchema = z.object({
  new_password: z.string().min(8, "At least 8 characters"),
});

type PasswordForm = z.infer<typeof PasswordSchema>;

export default function Account() {
  const { user, signOut } = useAuth();
  const { data: profile, isLoading, update } = useProfile();

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting: savingProfile },
  } = useForm<ProfileForm>({
    resolver: zodResolver(ProfileSchema),
    defaultValues: { display_name: "", avatar_url: "", phone: "" },
  });

  useEffect(() => {
    // Load profile defaults when fetched
    if (profile) {
      reset({
        display_name: profile.display_name ?? "",
        avatar_url: profile.avatar_url ?? "",
        phone: profile.phone ?? "",
      });
    }
  }, [profile, reset]);

  // Password form
  const {
    register: registerPw,
    handleSubmit: handleSubmitPw,
    reset: resetPw,
    formState: { errors: pwErrors, isSubmitting: savingPw },
  } = useForm<PasswordForm>({
    resolver: zodResolver(PasswordSchema),
    defaultValues: { new_password: "" },
  });

  const onSaveProfile = async (vals: ProfileForm) => {
    await update.mutateAsync(vals); // upsert { id: user!.id, ...vals } inside hook
  };

  const onChangePassword = async (vals: PasswordForm) => {
    // Uses Supabase Auth to update password for current user
    const { error } = await (await import("@/lib/supabase")).supabase.auth.updateUser({
      password: vals.new_password,
    });
    if (error) throw error;
    resetPw({ new_password: "" });
  };

  if (!user) return null; // Protected route should guard this already

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Account</CardTitle>
          <CardDescription>Manage your profile and sign-in details.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Readonly basics */}
          <div className="grid gap-2">
            <Label>Email</Label>
            <Input value={user.email ?? ""} disabled />
          </div>

          <Separator />

          {/* Profile form */}
          <form onSubmit={handleSubmit(onSaveProfile)} className="grid gap-4">
            
            {/* Display Name */}
            <div className="grid gap-2">
              <Label htmlFor="display_name">Display name</Label>
              <Input id="display_name" placeholder="Jane Doe" {...register("display_name")} />
              {errors.display_name && <p className="text-sm text-destructive">{errors.display_name.message}</p>}
            </div>

            {/* Avatar URL */}
            <div className="grid gap-2">
              <Label htmlFor="avatar_url">Avatar URL (optional)</Label>
              <Input id="avatar_url" placeholder="https://…" {...register("avatar_url")} />
              {errors.avatar_url && <p className="text-sm text-destructive">{errors.avatar_url.message}</p>}
              {/* If you later want uploads, swap this for your ImagePickerOptimize and set avatar_url to a blob URL or uploaded URL */}
            </div>

            {/* Phone Number */}
            <div className="grid gap-2">
              <Label htmlFor="phone">Phone number (optional)</Label>
              <Input id="phone" placeholder="+1 (555) 123-4567" {...register("phone")} />
              {errors.phone && <p className="text-sm text-destructive">{errors.phone.message}</p>}
            </div>

            {update.isError && (
              <Alert variant="destructive">
                <AlertDescription>{String((update.error as any)?.message ?? "Save failed")}</AlertDescription>
              </Alert>
            )}
            {update.isSuccess && (
              <Alert>
                <AlertDescription>Profile updated.</AlertDescription>
              </Alert>
            )}

            <div className="flex items-center gap-2">
              <Button type="submit" disabled={savingProfile || isLoading}>
                {savingProfile ? "Saving…" : "Save changes"}
              </Button>
              <Button type="button" variant="outline" onClick={() => reset()}>
                Reset
              </Button>
            </div>
          </form>

          <Separator />

          {/* Password change */}
          <form onSubmit={handleSubmitPw(onChangePassword)} className="grid gap-3">
            <div className="grid gap-2">
              <Label htmlFor="new_password">New password</Label>
              <Input id="new_password" type="password" placeholder="••••••••" {...registerPw("new_password")} />
              {pwErrors.new_password && (
                <p className="text-sm text-destructive">{pwErrors.new_password.message}</p>
              )}
            </div>

            <div className="flex items-center gap-2">
              <Button type="submit" disabled={savingPw}>
                {savingPw ? "Updating…" : "Update password"}
              </Button>
            </div>
          </form>
        </CardContent>

        <CardFooter className="flex items-center justify-between">
          <div className="text-sm text-muted-foreground">
            Signed in as <span className="text-foreground">{user.email}</span>
          </div>
          <Button variant="ghost" onClick={() => signOut()}>
            Sign out
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}

import { Outlet, NavLink, useLocation, Link } from "react-router-dom";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Sheet, SheetTrigger, SheetContent } from "@/components/ui/sheet";
import {
  DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuSeparator, DropdownMenuLabel
} from "@/components/ui/dropdown-menu";
import { Menu, LogOut, User, LayoutDashboard, LogIn, UserPlus } from "lucide-react";
import { useAuth } from "@/auth/AuthProvider";
import * as React from "react";
import { useProfile } from "@/profile/useProfile";
import Logo from "@/components/Logo";
import Footer from "@/components/Footer";
// Removed invalid import of M


/** Nav link with "startsWith" matching so parent tabs stay active on subroutes */
const NavItem = ({ to, children }: { to: string; children: React.ReactNode }) => {
  const { pathname } = useLocation();
  const active = pathname === to || pathname.startsWith(to + "/");
  return (
    <NavLink
      to={to}
      aria-current={active ? "page" : undefined}
      className={`rounded-lg px-3 py-2 text-sm font-medium transition-all duration-200
        ${active 
          ? "bg-primary text-primary-foreground shadow-sm" 
          : "text-muted-foreground hover:text-foreground hover:bg-secondary/80"
        }`}
    >
      {children}
    </NavLink>
  );
};

/** Mobile nav item with icons */
const MobileNavItem = ({ 
  to, 
  children, 
  icon 
}: { 
  to: string; 
  children: React.ReactNode;
  icon: React.ReactNode;
}) => {
  const { pathname } = useLocation();
  const active = pathname === to || pathname.startsWith(to + "/");
  return (
    <NavLink
      to={to}
      aria-current={active ? "page" : undefined}
      className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-all duration-200
        ${active 
          ? "bg-primary text-primary-foreground shadow-sm" 
          : "text-muted-foreground hover:text-foreground hover:bg-secondary/80"
        }`}
    >
      {icon}
      {children}
    </NavLink>
  );
};

export default function AppLayout() {
  const { user, loading, signOut } = useAuth();
  const { data: profile } = useProfile();

  console.log(profile);

  const displayName =
    profile?.display_name ||
    user?.user_metadata?.name ||
    user?.email;

  const initials =
    (profile?.display_name || user?.user_metadata?.name || user?.email || "U")
      .split(" ")
      .map((n: string) => n[0])
      .slice(0, 2)
      .join("")
      .toUpperCase();

  return (
    <div className="min-h-svh bg-background text-foreground">
      {/* Skip link for a11y */}
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:fixed focus:top-2 focus:left-2 focus:z-[100] rounded-md bg-primary px-3 py-1.5 text-primary-foreground"
      >
        Skip to content
      </a>

      {/* Top Bar */}
      <header className="sticky top-0 z-40 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80 shadow-sm">
        <div className="container mx-auto">
          <div className="flex h-16 items-center justify-between px-4 sm:px-6">
            <div className="flex items-center gap-2">
              {/* Mobile sidebar */}
              <Sheet>
                <SheetTrigger asChild>
                  <Button 
                    variant="outline" 
                    size="icon" 
                    className="md:hidden transition-all hover:scale-105"
                  >
                    <Menu className="h-5 w-5" />
                    <span className="sr-only">Toggle menu</span>
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="w-72 p-0">
                  <div className="border-b px-4 py-4">
                    <Logo showText={true} size="sm" to="/" />
                  </div>
                  <nav className="grid gap-1 p-3">
                    {!loading && user && (
                      <>
                        <MobileNavItem to="/dashboard" icon={<LayoutDashboard className="h-4 w-4" />}>
                          Dashboard
                        </MobileNavItem>
                        <MobileNavItem to="/account" icon={<User className="h-4 w-4" />}>
                          Account
                        </MobileNavItem>
                        {/* feedback */}
                        <MobileNavItem to="/feedback" icon={<LayoutDashboard className="h-4 w-4" />}>
                          Feedback
                        </MobileNavItem>

                        {/* Review Moderation if admin or owner */}
                        {(profile?.role === "admin" || profile?.role === "owner") && (
                          <MobileNavItem to="/reviews/moderation" icon={<LayoutDashboard className="h-4 w-4" />}>
                            Review Moderation
                          </MobileNavItem>
                        )}

        

                      </>
                    )}
                    {!loading && !user && (
                      <>
                        <MobileNavItem to="/signin" icon={<LogIn className="h-4 w-4" />}>
                          Sign in
                        </MobileNavItem>
                        <MobileNavItem to="/register" icon={<UserPlus className="h-4 w-4" />}>
                          Sign up
                        </MobileNavItem>
                      </>
                    )}
                  </nav>
                </SheetContent>
              </Sheet>

              <Logo />
              
              {/* Desktop Navigation - Only show when logged in */}
              {!loading && user && (
                <>
                  <Separator orientation="vertical" className="mx-3 hidden h-6 md:block" />
                  <nav className="hidden items-center gap-1 md:flex">
                    <NavItem to="/dashboard">Dashboard</NavItem>
                    <NavItem to="/account">Account</NavItem>
                    {/* feedback */}
                    <NavItem to="/feedback">Feedback</NavItem>

                    {/* Review Moderation */}
                    {(profile?.role === "admin" || profile?.role === "owner") && (
                      <NavItem to="/reviews/moderation">Review Moderation</NavItem>
                    )}
                  </nav>
                </>
              )}
            </div>

            {/* Right side: Auth */}
            <div className="flex items-center gap-3">
              {loading ? (
                <div className="flex items-center gap-2">
                  <div className="h-9 w-20 animate-pulse rounded-lg bg-secondary" />
                  <div className="h-9 w-20 animate-pulse rounded-lg bg-secondary" />
                </div>
              ) : !user ? (
                <div className="flex items-center gap-2">
                  <Button 
                    asChild 
                    variant="ghost"
                    className="transition-all hover:scale-105"
                  >
                    <Link to="/signin" className="flex items-center gap-2">
                      <LogIn className="h-4 w-4" />
                      <span className="hidden sm:inline">Sign in</span>
                    </Link>
                  </Button>
                  <Button 
                    asChild
                    className="transition-all hover:scale-105"
                  >
                    <Link to="/register" className="flex items-center gap-2">
                      <UserPlus className="h-4 w-4" />
                      <span className="hidden sm:inline">Sign up</span>
                    </Link>
                  </Button>
                </div>
              ) : (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button 
                      variant="ghost" 
                      className="gap-2 transition-all hover:scale-105"
                    >
                      <Avatar className="h-7 w-7 ring-2 ring-primary/10">
                        <AvatarImage src={user?.user_metadata?.avatar_url} alt="avatar" />
                        <AvatarFallback className="bg-primary/10 text-primary font-semibold text-xs">
                          {initials}
                        </AvatarFallback>
                      </Avatar>
                      <span className="hidden sm:inline font-medium">
                        {displayName}
                      </span>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-56">
                    <DropdownMenuLabel className="font-normal">
                      <div className="flex flex-col space-y-1">
                        <p className="text-sm font-medium leading-none">{displayName}</p>
                        <p className="text-xs leading-none text-muted-foreground">
                          {user?.email}
                        </p>
                      </div>
                    </DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem asChild>
                      <Link to="/dashboard" className="flex items-center gap-2 cursor-pointer">
                        <LayoutDashboard className="h-4 w-4" />
                        Dashboard
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link to="/account" className="flex items-center gap-2 cursor-pointer">
                        <User className="h-4 w-4" />
                        Account Settings
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem
                      onClick={async () => {
                        await signOut();
                      }}
                      className="text-destructive focus:text-destructive cursor-pointer flex items-center gap-2"
                    >
                      <LogOut className="h-4 w-4" />
                      Sign out
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Page content */}
      <main id="main" className="container mx-auto px-4 sm:px-6 py-6 md:py-8">
        <div className="mx-auto max-w-6xl">
          <Outlet />
        </div>
      </main>

      {/* Footer */}
      <Footer className="mt-auto" />
    </div>
  );
}
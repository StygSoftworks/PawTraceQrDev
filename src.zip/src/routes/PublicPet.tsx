// src/routes/PublicPet.tsx
import { useParams } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { supabase } from "@/lib/supabase";
import Logo from "@/components/Logo";

// Minimal shape for public view (avoid leaking owner_id, notes, etc.)
type PublicPet = {
  id: string;
  name: string;
  species: "dog" | "cat" | "other";
  breed: string | null;
  description: string | null;
  color: string | null;
  photo_url: string | null;
  missing: boolean;
  missing_since: string | null; // ISO
  short_id: string;
};

function timeSince(iso?: string | null) {
  if (!iso) return "";
  const start = new Date(iso).getTime();
  const now = Date.now();
  if (isNaN(start) || now <= start) return "just now";

  const diff = now - start;
  const mins = Math.floor(diff / (1000 * 60));
  const hours = Math.floor(mins / 60);
  const days = Math.floor(hours / 24);

  if (days > 0) {
    const rHours = hours % 24;
    return `${days} day${days>1?"s":""}${rHours ? `, ${rHours} hour${rHours>1?"s":""}` : ""}`;
  }
  if (hours > 0) {
    const rMins = mins % 60;
    return `${hours} hour${hours>1?"s":""}${rMins ? `, ${rMins} min` : ""}`;
  }
  return `${mins} min`;
}

export default function PublicPet() {
  const { id } = useParams();

  const { data, isLoading, isError } = useQuery({
    queryKey: ["public-pet", id],
    enabled: !!id,
    queryFn: async (): Promise<PublicPet | null> => {
      // Fetch just the fields you want to expose publicly
      const { data, error } = await supabase
        .from("public_pets")
        .select("*")
        .eq("short_id", id)
        .maybeSingle();

      if (error) throw error;
      return data as PublicPet | null;
    },
    staleTime: 60_000,
  });

  return (
    <div className="min-h-svh bg-background text-foreground">
      {/* Slim header */}
      <header className="sticky top-0 z-30 border-b bg-background/70 backdrop-blur">
        <div className="mx-auto flex h-14 max-w-4xl items-center justify-between px-4">
          <Logo />
        </div>
      </header>

      <main className="mx-auto max-w-4xl p-4 md:p-6">
        {isLoading ? (
          <Card className="overflow-hidden">
            <div className="grid gap-4 p-4 md:grid-cols-[240px,1fr]">
              <Skeleton className="h-48 w-full" />
              <div className="space-y-3">
                <Skeleton className="h-6 w-40" />
                <Skeleton className="h-4 w-56" />
                <Skeleton className="h-4 w-48" />
                <Skeleton className="h-4 w-72" />
              </div>
            </div>
          </Card>
        ) : isError || !data ? (
          <Card>
            <CardHeader>
              <CardTitle>Pet not found</CardTitle>
              <CardDescription>
                The QR link is invalid or this pet is no longer available.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button asChild>
                <a href="/">Go to homepage</a>
              </Button>
            </CardContent>
          </Card>
        ) : (
          <Card className="overflow-hidden">
            <CardHeader className="flex flex-col gap-2 md:flex-row md:items-center md:justify-between">
              <CardTitle className="flex items-center gap-3">
                <span className="truncate">{data.name}</span>
                {data.missing ? (
                  <Badge variant="destructive">Missing</Badge>
                ) : (
                  <Badge variant="success">Not Missing</Badge>
                )}
              </CardTitle>
              <CardDescription className="flex flex-wrap items-center gap-2">
                <Badge variant="secondary" className="capitalize">{data.species}</Badge>
                {data.breed && <Badge variant="outline">{data.breed}</Badge>}
                {data.color && <Badge variant="outline">{data.color}</Badge>}
                {data.missing && data.missing_since && (
                  <span className="text-sm text-muted-foreground">
                    Missing for {timeSince(data.missing_since)}
                  </span>
                )}
              </CardDescription>
            </CardHeader>

            <CardContent className="grid gap-4 md:grid-cols-[280px,1fr]">
              {data.photo_url ? (
                <img
                  src={data.photo_url}
                  alt={`${data.name} photo`}
                  className="h-64 w-full rounded-md object-cover border bg-white"
                  loading="lazy"
                />
              ) : (
                <div className="flex h-64 w-full items-center justify-center rounded-md border text-sm text-muted-foreground">
                  No photo provided
                </div>
              )}

              <div className="space-y-4">
                <div>
                  <div className="text-sm font-medium">About</div>
                  <p className="text-sm text-muted-foreground">
                    {data.description || "No description provided."}
                  </p>
                </div>

                {/* If you want a contact action, link to a “found” form or mailto */}
                {/* Example (optional):
                <div className="flex flex-wrap gap-2">
                  <Button asChild>
                    <a href={`/found/${data.id}`}>I found this pet</a>
                  </Button>
                  <Button variant="outline" asChild>
                    <a href={`mailto:support@yourapp.com?subject=Found ${encodeURIComponent(data.name)}`}>
                      Contact owner
                    </a>
                  </Button>
                </div>
                */}
              </div>
            </CardContent>
          </Card>
        )}
      </main>
    </div>
  );
}

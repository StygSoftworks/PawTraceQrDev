// src/components/Logo.tsx
import { Link } from "react-router-dom";

interface LogoProps {
  to?: string;
  size?: "sm" | "md" | "lg";
  showText?: boolean;
  className?: string;
}

const sizeClasses = {
  sm: "h-8 w-8",
  md: "h-12 w-12",
  lg: "h-16 w-16",
};

const textSizeClasses = {
  sm: "text-base",
  md: "text-xl",
  lg: "text-2xl",
};

export default function Logo({ 
  to = "/", 
  size = "md", 
  showText = true,
  className = "" 
}: LogoProps) {
  return (
    <Link 
      to={to} 
      className={`flex items-center gap-3 group ${className}`}
    >
      <div className={`${sizeClasses[size]} flex items-center justify-center`}>
        <img 
          src="/PawTraceQRLogo.svg" 
          alt="PawTrace Logo" 
          className="w-full h-full object-contain transition-transform duration-200 group-hover:scale-110"
        />
      </div>
      {showText && (
        <span className={`${textSizeClasses[size]} font-bold text-foreground`}>
          PawTrace QR
        </span>
      )}
    </Link>
  );
}